#ifndef LEDINV_H
#define LEDINV_H

#include "led.h"

extern unsigned char ucInversion;

class LedInv
				:private Led{
public:
	void On(unsigned char ucLedIndex);
};
	
#endif
