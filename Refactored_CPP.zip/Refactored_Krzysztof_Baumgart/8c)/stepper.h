#ifndef STEPPER_H
#define STEPPER_H

#include "led.h"
#include "ledinv.h"

enum Step {LEFT, RIGHT};

class Stepper
{
private:
	unsigned char ucLedCtr;
	Led myLed;
	LedInv myLedInv;
	void Step(enum Step eStep);	
public:
	void StepRight(void);
	void StepLeft(void);
};

#endif
