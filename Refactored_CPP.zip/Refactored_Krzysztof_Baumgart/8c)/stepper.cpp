#include "stepper.h"
#include "led.h"

extern unsigned char ucInversion;

void Stepper::Step(enum Step eStep){
	if(eStep == LEFT){
		ucLedCtr--;
	}
	else if(eStep == RIGHT){
		ucLedCtr++;
	}
	ucLedCtr = ucLedCtr % 4;
	if(ucInversion){
		myLedInv.On(ucLedCtr);
	}
	else{
		myLed.On(ucLedCtr);
	}
}

void Stepper::StepLeft(void){
	Step(LEFT);
}

void Stepper::StepRight(void){
	Step(RIGHT);
}
