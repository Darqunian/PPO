#ifndef LEDINV_H
#define LEDINV_H

#include "led.h"

extern unsigned char ucInversion;

class LedInv
	:public Led{
public:
	virtual	void On(unsigned char ucLedIndex);
};
	
#endif
