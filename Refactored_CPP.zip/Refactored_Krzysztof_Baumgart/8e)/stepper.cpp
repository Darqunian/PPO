#include "stepper.h"
#include "led.h"

void Stepper::Step(enum Step eStep){
	if(eStep == LEFT){
		ucLedCtr--;
	}
	else if(eStep == RIGHT){
		ucLedCtr++;
	}
	ucLedCtr = ucLedCtr % 4;
	pLed->On(ucLedCtr);
}

void Stepper::SetLed(Led* pLedMode){
	pLed = pLedMode;
}

void Stepper::StepLeft(void){
	Step(LEFT);
}

void Stepper::StepRight(void){
	Step(RIGHT);
}
