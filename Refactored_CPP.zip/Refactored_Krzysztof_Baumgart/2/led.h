#ifndef LED_H
#define LED_H

enum  Step {LEFT, RIGHT};

class Led{
private:
	unsigned char ucLedCtr;
	void Step(enum Step eStep);
	void On(unsigned char ucLedIndex);
public:
	void Init(void);
	void StepLeft(void);
	void StepRight(void);
};
	
#endif
