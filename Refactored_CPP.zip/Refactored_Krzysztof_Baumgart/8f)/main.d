.\main.o: main.cpp
.\main.o: led.h
.\main.o: ledinv.h
.\main.o: ledpos.h
.\main.o: stepper.h
.\main.o: keyboard.h
