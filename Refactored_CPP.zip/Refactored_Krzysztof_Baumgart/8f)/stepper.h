#ifndef STEPPER_H
#define STEPPER_H

#include "led.h"
#include "ledinv.h"

enum Step {LEFT, RIGHT};

class Stepper
{
private:
	unsigned char ucLedCtr;
	unsigned char ucInversion;
	Led* pLed;
	void Step(enum Step eStep);	
public:
	void SetLed(Led* pLedMode);
	void StepRight(void);
	void StepLeft(void);
};

#endif
