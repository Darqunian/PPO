#include "stepper.h"
#include "led.h"

extern Led myLed;

Stepper::Stepper(unsigned char ucLedPosition) {
	ucLedCtr = ucLedPosition;
	myLed.On(ucLedCtr);
}

void Stepper::Step(enum Step eStep){
	if(eStep == LEFT){
		ucLedCtr--;
	}
	else if(eStep == RIGHT){
		ucLedCtr++;
	}
	ucLedCtr = ucLedCtr % 4;
	myLed.On(ucLedCtr);
}

void Stepper::StepLeft(void){
	Step(LEFT);
}

void Stepper::StepRight(void){
	Step(RIGHT);
}
