#ifndef STEPPER_H
#define STEPPER_H

#include "led.h"

enum Step {LEFT, RIGHT};

class Stepper
				:private Led
{
private:
	unsigned char ucLedCtr;
	void Step(enum Step eStep);
public:
	Stepper();
	void StepRight(void);
	void StepLeft(void);
};

#endif
