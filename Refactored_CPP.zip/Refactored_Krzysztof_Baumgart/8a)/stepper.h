#ifndef STEPPER_H
#define STEPPER_H

#include "led.h"

enum Step {LEFT, RIGHT};

class Stepper
{
private:
	unsigned char ucLedCtr;
	Led myLed;
	void Step(enum Step eStep);	
public:
	void StepRight(void);
	void StepLeft(void);
};

#endif
