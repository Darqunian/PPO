#include "stepper.h"
#include "keyboard.h"

void Delay(int iTimeInMs){
	int iCycle;
	int iNumberOfCycles = 10000 * iTimeInMs;
	
	for (iCycle = 0; iCycle < iNumberOfCycles; iCycle++) {}
}

Stepper myStep;

int main(void)
{
	Keyboard myKeyboard;
	
	while(1){
		Delay(120);
		switch(myKeyboard.eRead()){
		case BUTTON_1:
			myStep.StepRight();
		break;
		case BUTTON_2:
			myStep.StepLeft();
		break;
		default:
		break;
		}
	}
}
