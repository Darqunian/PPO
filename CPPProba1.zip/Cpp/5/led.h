#ifndef LED_H
#define LED_H

class Led {
protected:
	Led(void);
	void On(unsigned char);

};
#endif
