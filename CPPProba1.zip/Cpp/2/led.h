#ifndef LED_H
#define LED_H

class Led {
public:
	void Init(void);
	void StepRight(void);
	void StepLeft(void);
private:
	unsigned char ucLedCtr;
	void On(unsigned char);
	void Step(enum Step);

};
#endif
