#include "stepper.h"
#include "Keyboard.h"

Stepper MyStepper;

void Delay(int iTimeInMs){
	int iCycle;
	int iNumberOfCycles = 10000 * iTimeInMs;
	
	for (iCycle = 0; iCycle < iNumberOfCycles; iCycle++) {}
}

int main(void)
{
	Keyboard MyKeyboard;
	if(MyKeyboard.eRead() == BUTTON_4){
		MyStepper.SetMode(1);
	}
	else{
		MyStepper.SetMode(0);
	}
	
	while(1){
		switch(MyKeyboard.eRead()){
			case BUTTON_1:
				MyStepper.StepRight();
			break;
			case BUTTON_2:
				MyStepper.StepLeft();
			break;
			default:
			break;
		}
		Delay(500);
	}
}
