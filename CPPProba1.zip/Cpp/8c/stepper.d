.\stepper.o: stepper.cpp
.\stepper.o: stepper.h
.\stepper.o: ledInv.h
.\stepper.o: led.h
