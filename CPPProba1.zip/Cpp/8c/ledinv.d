.\ledinv.o: ledInv.cpp
.\ledinv.o: C:\Keil\ARM\Inc\Philips\LPC21xx.H
.\ledinv.o: ledInv.h
.\ledinv.o: led.h
