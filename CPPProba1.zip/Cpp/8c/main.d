.\main.o: main.cpp
.\main.o: stepper.h
.\main.o: ledInv.h
.\main.o: led.h
.\main.o: Keyboard.h
