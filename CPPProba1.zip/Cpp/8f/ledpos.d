.\ledpos.o: ledPos.cpp
.\ledpos.o: C:\Keil\ARM\Inc\Philips\LPC21xx.H
.\ledpos.o: ledPos.h
.\ledpos.o: led.h
