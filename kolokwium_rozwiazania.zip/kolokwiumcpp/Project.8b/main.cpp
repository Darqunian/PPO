#include "stepper.h"
#include "keyboard.h"

unsigned char ucInversion;

void Delay(int iTimeInMs){
	int iCycle;
	int iNumberOfCycles = 12000 * iTimeInMs;
	
	for (iCycle = 0; iCycle < iNumberOfCycles; iCycle++) {}
}

int main()
{
	Keyboard MyKeyboard;
	
	if (MyKeyboard.eRead() == BUTTON_4){
		ucInversion = 1;
	}
	else{
		ucInversion = 0;
	}
	
	Stepper MyStepper;
	

	while(1){
		Delay(500);
		if(MyKeyboard.eRead() == BUTTON_1){
			MyStepper.StepRight();
		}
		else if(MyKeyboard.eRead() == BUTTON_2){
			MyStepper.StepLeft();
		}
		else{
		}
	}
}
