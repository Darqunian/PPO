.\keyboard.o: keyboard.cpp
.\keyboard.o: C:\Studia\Keil\ARM\Inc\Philips\LPC21xx.H
.\keyboard.o: keyboard.h
