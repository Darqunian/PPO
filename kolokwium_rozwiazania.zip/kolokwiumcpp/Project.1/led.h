#ifndef LED_H
#define LED_H

void LedStepRight();
void LedStepLeft();
void LedInit();

#endif
