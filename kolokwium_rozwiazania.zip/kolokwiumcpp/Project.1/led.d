.\led.o: led.cpp
.\led.o: C:\Studia\Keil\ARM\Inc\Philips\LPC21xx.H
.\led.o: led.h
