#ifndef STEPPER_H
#define STEPPER_H

#include "led.h"

class Stepper 
{
	public:
		void StepLeft();
		void StepRight();
	private:
		unsigned char LedCtr;
		Led MyLed;
	
		void Step(enum Step);
	
};


#endif
