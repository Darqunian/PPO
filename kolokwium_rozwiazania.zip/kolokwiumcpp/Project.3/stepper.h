#ifndef STEPPER_H
#define STEPPER_H

class Stepper{
	public:
		void StepLeft();
		void StepRight();
	private:
		unsigned char LedCtr;
	
		void Step(enum Step);
	
};


#endif
