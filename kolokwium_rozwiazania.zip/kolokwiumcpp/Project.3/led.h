#ifndef LED_H
#define LED_H

class Led{
	public:
		void Init();
		void On(unsigned char);
};

#endif
