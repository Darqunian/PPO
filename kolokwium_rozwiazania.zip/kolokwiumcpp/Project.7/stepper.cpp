#include "stepper.h"

enum Step{LEFT,RIGHT};

Stepper::Stepper(unsigned char ucLedStart){
	Stepper::LedCtr = ucLedStart;
	Stepper::MyLed.On(Stepper::LedCtr);
	
}

void Stepper::Step(enum Step eStep){
	if(eStep == LEFT){
		Stepper::LedCtr--;
		Stepper::LedCtr = Stepper::LedCtr % 4;
		Stepper::MyLed.On(Stepper::LedCtr);
	}
	else if(eStep == RIGHT){
		Stepper::LedCtr++;
		Stepper::LedCtr = Stepper::LedCtr % 4;
		Stepper::MyLed.On(Stepper::LedCtr);
	}else{
	}
}

void Stepper::StepLeft(){
	Stepper::Step(LEFT);
}


void Stepper::StepRight(){
	Stepper::Step(RIGHT);
}
