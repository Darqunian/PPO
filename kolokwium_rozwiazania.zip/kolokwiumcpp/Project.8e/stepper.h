#ifndef STEPPER_H
#define STEPPER_H

#include "led.h"

class Stepper 
{
	public:
		void SetLed(Led *);
		void StepLeft();
		void StepRight();
	private:
		unsigned char LedCtr;
		Led *pMyLed;
	
		void Step(enum Step);
	
};


#endif
