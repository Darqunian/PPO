#include "stepper.h"

enum Step{LEFT,RIGHT};


void Stepper::Step(enum Step eStep){
	if(eStep == LEFT){
		Stepper::LedCtr--;
		Stepper::LedCtr = Stepper::LedCtr % 4;
		Stepper::pMyLed->On(Stepper::LedCtr);
	}
	else if(eStep == RIGHT){
		Stepper::LedCtr++;
		Stepper::LedCtr = Stepper::LedCtr % 4;
		Stepper::pMyLed->On(Stepper::LedCtr);
	}else{
	}
}

void Stepper::StepLeft(){
	Stepper::Step(LEFT);
}


void Stepper::StepRight(){
	Stepper::Step(RIGHT);
}

void Stepper::SetLed(Led *LedFunction){
	Stepper::pMyLed = LedFunction;
}
