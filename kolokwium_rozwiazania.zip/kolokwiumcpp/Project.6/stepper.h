#ifndef STEPPER_H
#define STEPPER_H

#include "led.h"

class Stepper 
		:	public Led
{
	public:
		Stepper(unsigned char = 0);
		void StepLeft();
		void StepRight();
	private:
		unsigned char LedCtr;
	
		void Step(enum Step);
	
};


#endif
