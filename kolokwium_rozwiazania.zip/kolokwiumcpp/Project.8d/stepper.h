#ifndef STEPPER_H
#define STEPPER_H

#include "ledinv.h"

class Stepper 
{
	public:
		void SetMode(unsigned char);
		void StepLeft();
		void StepRight();
	private:
		unsigned char LedCtr;
		unsigned char ucInversion;
		Led MyLed;
		LedInv MyLedInv;
	
		void Step(enum Step);
	
};


#endif
