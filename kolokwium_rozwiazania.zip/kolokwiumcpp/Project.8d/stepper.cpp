#include "stepper.h"

enum Step{LEFT,RIGHT};


void Stepper::Step(enum Step eStep){
	if(eStep == LEFT){
		Stepper::LedCtr--;
		Stepper::LedCtr = Stepper::LedCtr % 4;
		if(Stepper::ucInversion == 1){
			Stepper::MyLedInv.On(Stepper::LedCtr);
		}
		else{
			Stepper::MyLed.On(Stepper::LedCtr);
		}
	}
	else if(eStep == RIGHT){
		Stepper::LedCtr++;
		Stepper::LedCtr = Stepper::LedCtr % 4;
		if(Stepper::ucInversion == 1){
			Stepper::MyLedInv.On(Stepper::LedCtr);
		}
		else{
			Stepper::MyLed.On(Stepper::LedCtr);
		};
	}else{
	}
}

void Stepper::StepLeft(){
	Stepper::Step(LEFT);
}


void Stepper::StepRight(){
	Stepper::Step(RIGHT);
}

void Stepper::SetMode(unsigned char ucLedMode){
	Stepper::ucInversion = ucLedMode;
}
