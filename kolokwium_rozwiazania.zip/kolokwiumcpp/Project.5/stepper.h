#ifndef STEPPER_H
#define STEPPER_H

#include "led.h"

class Stepper 
		:	public Led
{
	public:
		void StepLeft();
		void StepRight();
	private:
		unsigned char LedCtr;
	
		void Step(enum Step);
	
};


#endif
