#ifndef STEPPER_H
#define STEPPER_H

#include "ledinv.h"

class Stepper 
{
	public:
		void StepLeft();
		void StepRight();
	private:
		unsigned char LedCtr;
		Led MyLed;
		LedInv MyLedInv;
	
		void Step(enum Step);
	
};


#endif
