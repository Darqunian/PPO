.\ledinv.o: ledinv.cpp
.\ledinv.o: ledinv.h
.\ledinv.o: led.h
.\ledinv.o: C:\Studia\Keil\ARM\Inc\Philips\LPC21xx.H
