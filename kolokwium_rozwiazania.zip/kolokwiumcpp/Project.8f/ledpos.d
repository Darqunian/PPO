.\ledpos.o: ledpos.cpp
.\ledpos.o: ledpos.h
.\ledpos.o: led.h
.\ledpos.o: C:\Studia\Keil\ARM\Inc\Philips\LPC21xx.H
