#ifndef STEPPER_H
#define STEPPER_H

#include "led.h"

class Stepper: private Led
{
	public:
		void StepRight(void);
		void StepLeft(void);
		Stepper(unsigned char = 0);
	
	private:
		unsigned char ucLedCtr;
		void Step(enum Step);
};

#endif