.\main.o: main.cpp
.\main.o: stepper.h
.\main.o: keyboard.h
.\main.o: ledinv.h
.\main.o: led.h
