#include "stepper.h"
#include "ledinv.h"

enum Step{LEFT,RIGHT};

void Stepper::SetMode(unsigned char ucLedWrite)
{
	ucInversion = ucLedWrite;
}

void Stepper::Step(enum Step eStep){
	if(eStep == LEFT){
		ucLedCtr--;
	}
	else if(eStep == RIGHT){
		ucLedCtr++;
	}else{
	}
		ucLedCtr = ucLedCtr % 4;
		if(ucInversion){
			MyLedInv.On(ucLedCtr);
		}
		else{
			MyLed.On(ucLedCtr);
		}
}

void Stepper::StepLeft(void){
	Step(LEFT);
}

void Stepper::StepRight(void){
	Step(RIGHT);
}
